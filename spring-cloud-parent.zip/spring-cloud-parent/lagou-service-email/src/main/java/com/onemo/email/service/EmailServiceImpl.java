package com.onemo.email.service;

import com.onemo.common.exception.LagouCloudException;
import com.onemo.email.utils.MailUtils;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;


@Service
@Slf4j
public class EmailServiceImpl implements EmailService {
    Logger log = LoggerFactory.getLogger(EmailServiceImpl.class);
    @Override
    public boolean send(String email, String code) {
        return sendCodeToEmail(email, code);
    }


    private static final String DEFAULT_TITLE = "拉钩spring cloud课程验证码";

    private boolean sendCodeToEmail(String email, String code) {
        try {
            log.info("send email[{}] code[{}]", email, code);
            MailUtils.sendMail(email, DEFAULT_TITLE, "您好！您的验证码为" + code + ". 有效时间为10分钟，请在有效时间内使用");
            return true;
        } catch (MessagingException e) {
            log.error("send email fail; email is {}. code is {}", email, code);
            throw new LagouCloudException("发送邮件失败");
        }
    }
}
