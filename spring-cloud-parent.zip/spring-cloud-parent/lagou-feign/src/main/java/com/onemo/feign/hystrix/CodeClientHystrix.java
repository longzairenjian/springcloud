package com.onemo.feign.hystrix;

import com.onemo.common.module.ResultData;
import com.onemo.feign.CodeClient;
import org.springframework.stereotype.Component;

@Component
public class CodeClientHystrix implements CodeClient {
    @Override
    public ResultData<Boolean> create(String email) {
        return null;
    }

    @Override
    public ResultData<Integer> validate(String email, String code) {
        return null;
    }
}
