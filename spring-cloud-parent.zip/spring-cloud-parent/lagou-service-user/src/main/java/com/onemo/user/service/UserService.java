package com.onemo.user.service;

public interface UserService {

    /**
     * 用户登录接口
     *
     * @param email    邮箱
     * @param password 密码
     * @return 用户的token令牌
     */
    String login(String email, String password);

    /**
     * 用户注册接口
     *
     * @param email    邮箱
     * @param password 密码
     * @param code     验证码
     * @return true 注册成功 false 注册失败
     */
    boolean register(String email, String password, String code);

    /**
     * 判断用户是否注册
     *
     * @param email 用户邮箱
     * @return true 已注册 false 未注册
     */
    boolean isRegister(String email);

    /**
     * 获取用户信息接口
     *
     * @param token 用户token
     * @return 用户邮箱
     */
    String userInfo(String token);
}
