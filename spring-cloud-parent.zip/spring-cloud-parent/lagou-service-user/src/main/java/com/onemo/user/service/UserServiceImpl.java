package com.onemo.user.service;

import com.onemo.common.exception.LagouCloudException;
import com.onemo.common.utils.ResultDataUtils;
import com.onemo.common.utils.TokenUtil;
import com.onemo.feign.CodeClient;
import com.onemo.user.entity.LagouToken;
import com.onemo.user.repository.LagouTokenRepository;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

@Service
public class UserServiceImpl implements UserService {

    @Resource
    private LagouTokenRepository lagouTokenRepository;

    @Resource
    private CodeClient codeClient;

    @Override
    public String login(String email, String password) {
        if (StringUtils.isBlank(email) || StringUtils.isBlank(password)) {
            throw new LagouCloudException("请求参数错误");
        }
        if (!isRegister(email)) {
            throw new LagouCloudException("不存在该邮箱账号");
        }
        LagouToken lagouToken = lagouTokenRepository.findByAndEmailAndPassword(email, password);
        if (Objects.isNull(lagouToken)) {
            throw new LagouCloudException("邮箱账号或者密码输入错误，请重新输入");
        }
        String token = lagouToken.getToken();
        ServletRequestAttributes servletRequestAttributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
        assert servletRequestAttributes != null;
        HttpServletResponse response = servletRequestAttributes.getResponse();
        Cookie cookie = new Cookie("token", token);
        Cookie cookieUser = new Cookie("user", email);
        cookie.setPath("/");
        cookieUser.setPath("/");
        assert response != null;
        response.addCookie(cookie);
        response.addCookie(cookieUser);
        response.addHeader("token", token);
        return lagouToken.getEmail();
    }

    @Override
    public boolean register(String email, String password, String code) {
        if (StringUtils.isBlank(email) || StringUtils.isBlank(password) || StringUtils.isBlank(code)) {
            throw new LagouCloudException("请求参数错误");
        }
        //1、校验用户是否已注册
        if (isRegister(email)) {
            throw new LagouCloudException("邮箱账号为：" + email + " 的用户已注册，请勿重复注册");
        }
        //2、校验用户验证码是否正确或超时 0正确1错误2超时
        Integer result = ResultDataUtils.parse(codeClient.validate(email, code));
        if (result == 1) {
            throw new LagouCloudException("验证码输入错误");
        } else if (result == 2) {
            throw new LagouCloudException("验证码已超时,请重新发送验证码");
        }
        //3、生成token
        String token = TokenUtil.token(email, password);
        //4、保存用户信息
        LagouToken lagouToken = new LagouToken();
        lagouToken.setEmail(email);
        lagouToken.setToken(token);
        lagouToken.setPassword(password);
        lagouTokenRepository.save(lagouToken);
        return true;
    }

    @Override
    public boolean isRegister(String email) {
        if (StringUtils.isBlank(email)) {
            return false;
        }
        return Objects.nonNull(lagouTokenRepository.findByAndEmail(email));
    }

    @Override
    public String userInfo(String token) {
        if (StringUtils.isBlank(token)) {
            throw new LagouCloudException("请求参数错误");
        }
        LagouToken lagouToken = lagouTokenRepository.findByAndToken(token);
        if (Objects.isNull(lagouToken)) {
            throw new LagouCloudException("不存在该用户，请重新登录后重试");
        }
        return lagouToken.getEmail();
    }
}
