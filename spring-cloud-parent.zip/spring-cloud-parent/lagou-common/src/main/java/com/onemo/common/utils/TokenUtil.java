package com.onemo.common.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.onemo.common.exception.LagouCloudException;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;


public class TokenUtil {

    //设置过期时间
    private static final long EXPIRE_DATE = 30 * 60 * 100000;
    //token秘钥
    private static final String TOKEN_SECRET = "ZCfasfhuaUUHufguGuwu2020BQWE";

    /**
     * 根据用户邮箱和密码生成一个token
     *
     * @param email    邮箱
     * @param password 密码
     * @return 该用户的token令牌
     */
    public static String token(String email, String password) {
        try {
            //过期时间
            Date date = new Date(System.currentTimeMillis() + EXPIRE_DATE);
            //秘钥及加密算法
            Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
            //设置头部信息
            Map<String, Object> header = new HashMap<>();
            header.put("typ", "JWT");
            header.put("alg", "HS256");
            //携带username，password信息，生成签名
            return JWT.create()
                    .withHeader(header)
                    .withClaim("email", email)
                    .withClaim("password", password).withExpiresAt(date)
                    .sign(algorithm);
        } catch (Exception e) {
            throw new LagouCloudException("生成token失败");
        }
    }

    /**
     * 校验token是否有效
     */
    public static boolean verify(String token) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(TOKEN_SECRET);
            JWTVerifier verifier = JWT.require(algorithm).build();
            verifier.verify(token);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /*public static void main(String[] args) {
        String username = "zhangsan";
        String password = "123";
        String token = token(username, password);
        System.out.println(token);
        boolean b = verify("eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwYXNzd29yZCI6IjEyMyIsImV4cCI6MTYwMjA2MTA0NCwiZW1haWwiOiJ6aGFuZ3NhbiJ9.-MOZs1-PzhP4ecACjwHdSvtlV_5E25tgs6r61_QxgL4");
        System.out.println(b);
    }*/
}