package com.onemo.common.advice;

import com.onemo.common.exception.LagouCloudException;
import com.onemo.common.module.ResultData;
import com.onemo.common.utils.ResultDataUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class ExceptionAdvice {

    @ExceptionHandler(value = LagouCloudException.class)
    @ResponseBody
    public ResultData<Void> bizExceptionHandler(LagouCloudException lagouCloudException) {
        return ResultDataUtils.createError(lagouCloudException.getCode(), lagouCloudException.getErrorMsg());
    }
}
