package com.onemo.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@ConfigurationProperties(prefix = "lagou.cloud.ip-black")
@Component
@Getter
@Setter
public class IpBlackProperties {

    /**
     * 需要限制的接口列表
     */
    private List<IpBlack> interfacePaths;

    @Getter
    @Setter
    public static class IpBlack {
        /**
         * 针对哪个接口做防暴刷
         */
        private String interfacePath;


        /**
         * 每隔多长时间限制访问
         */
        private Integer time;


        /**
         * 每隔指定的时间限制访问的次数
         */
        private Integer count;
    }
}
