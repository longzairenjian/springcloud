package com.onemo.code.controller;

import com.onemo.code.service.CodeService;
import com.onemo.common.module.ResultData;
import com.onemo.common.utils.ResultDataUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@RequestMapping("api/code")
public class CodeController {

    @Resource
    private CodeService codeService;

    /**
     * 生成验证码并发送到对应邮箱，成功true，失败false
     *
     * @param email 邮箱账号
     * @return true 成功 false 失败
     */
    @GetMapping("create/{email}")
    public ResultData<Boolean> create(@PathVariable("email") String email) {
        return ResultDataUtils.create(codeService.create(email));
    }


    /**
     * 校验验证码是否正确，0正确1错误2超时
     *
     * @param email 邮箱账号
     * @param code  验证码
     */
    @GetMapping("validate/{email}/{code}")
    public ResultData<Integer> validate(@PathVariable("email") String email, @PathVariable("code") String code) {
        return ResultDataUtils.create(codeService.validate(email, code));
    }

}
