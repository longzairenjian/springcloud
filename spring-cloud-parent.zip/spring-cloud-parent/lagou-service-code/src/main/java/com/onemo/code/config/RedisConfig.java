package com.onemo.code.config;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
public class RedisConfig {
 
    //自定义 RedisTemplate 序列化方式
    @Bean
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();//创建 RedisTemplate，key 和 value 都采用了 Object 类型
        redisTemplate.setConnectionFactory(redisConnectionFactory);//绑定 RedisConnectionFactory
 
        //创建 Jackson2JsonRedisSerializer 序列方式，对象类型使用 Object 类型，
        Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);
        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);
        jackson2JsonRedisSerializer.setObjectMapper(objectMapper);//设置一下 jackJson 的 ObjectMapper 对象参数
 
        // 设置 RedisTemplate 序列化规则。因为 key 通常是普通的字符串，所以使用 StringRedisSerializer 即可。
        // 而 value 是对象时，才需要使用序列化与反序列化
        redisTemplate.setKeySerializer(new StringRedisSerializer());// key 序列化规则
        redisTemplate.setValueSerializer(jackson2JsonRedisSerializer);// value 序列化规则
        redisTemplate.setHashKeySerializer(new StringRedisSerializer());// hash key 序列化规则
        redisTemplate.setHashValueSerializer(jackson2JsonRedisSerializer);// hash value 序列化规则
        redisTemplate.afterPropertiesSet();//属性设置后操作
        return redisTemplate;//返回设置好的 RedisTemplate
    }
}